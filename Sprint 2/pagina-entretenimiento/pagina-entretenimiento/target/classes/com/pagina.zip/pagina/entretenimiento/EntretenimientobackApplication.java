package com.pagina.entretenimiento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntretenimientobackApplication {

	public static void main(String[] args) {
		SpringApplication.run(EntretenimientobackApplication.class, args);
	}

}
